﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Here_Messanger
{
    static class General
    {
        public const string SP_FILE_NAME = "data.sp";
        public const string KEY_NAME = "Name";
        public const string KEY_MAIL = "mail";
        public const string KEY_PWD = "pwd";
        public const string KEY_CAMERA_IMAGE = "data";
        public const int REQUEST_REGISTER = 1;
    }
}